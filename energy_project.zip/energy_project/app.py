import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import base64

def get_base64_image(image_file):
  with open(image_file, "rb") as f:
   data = f.read()
  return base64.b64encode(data).decode()
img_base64 = get_base64_image("profile.png")



st.sidebar.markdown(
f""" <div style="text-align: center;"> <img src="data:image/png;base64,{img_base64}"
     style="width:80px; height:80px; border-radius:50%;
     border:4px solid #4CAF50;"> </div>
""",
unsafe_allow_html=True
)

st.sidebar.markdown("##    👤 Tanya Jain")
st.sidebar.markdown("    AI Energy System ⚡")

st.sidebar.markdown("---")

st.sidebar.write("⚡ Renewable Forecasting")
st.sidebar.write("🔋 Battery Optimization")
st.sidebar.write("💰 Cost Analysis")


# 🔷 Main Title
st.title("⚡ AI-Based Smart Energy Optimization System")
st.markdown("### Forecast → Optimize → Save Cost 🚀")

st.markdown("---")

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

st.title("⚡ Energy Dashboard")

# Load data

df = pd.read_csv("Renewable_energy_dataset.csv")

st.subheader("📊 Data Preview")
st.write(df.head())

# Graph

st.subheader("📈 Renewable Energy Over Time")

fig, ax = plt.subplots()
ax.plot(df["total_renewable_energy"])
st.pyplot(fig)

# Supply vs Demand Graph
# 👉 Renewable Supply vs Grid Demand compariso
st.subheader("⚡ Supply vs Demand Comparison")

fig2, ax2 = plt.subplots()
ax2.plot(df["total_renewable_energy"], label="Supply")
ax2.plot(df["grid_load_demand"], label="Demand")
ax2.legend()

st.pyplot(fig2)

# 👉 🔋 Battery simulation (real optimization logic)

st.subheader("🔋 Battery Simulation")

battery_capacity = 100
soc = 70

soc_list = []
grid_list = []

supply_col = "total_renewable_energy"
demand_col = "grid_load_demand"

for index, row in df.iterrows():
    # FIX 1: use row instead of undefined i
    supply = row[supply_col]
    demand = row[demand_col]

    # FIX 2: keep logic INSIDE loop
    if supply > demand:
        charge = min(supply - demand, battery_capacity - soc)
        soc += charge
        grid = -(supply - demand - charge)
    else:
        discharge = min(demand - supply, soc)
        soc -= discharge
        grid = demand - supply - discharge

    # append inside loop
    soc_list.append(soc)
    grid_list.append(grid)

# DEBUG
st.write("Length df:", len(df))
st.write("Length soc_list:", len(soc_list))

# assign back to dataframe
df["soc"] = soc_list
df["grid_exchange"] = grid_list


# 🔋 Battery SOC Graph

st.subheader("🔋 Battery State of Charge")

fig3, ax3 = plt.subplots()
ax3.plot(df["soc"], label="SOC")
ax3.set_title("Battery SOC Over Time")
ax3.legend()
st.pyplot(fig3)

# 🔌 Grid Exchange Graph

st.subheader("🔌 Grid Exchange")

fig4, ax4 = plt.subplots()
ax4.plot(df["grid_exchange"], label="Grid Exchange")
ax4.set_title("Grid Import / Export")
ax4.legend()
st.pyplot(fig4)

st.subheader("🤖 ML Predictions")

# Features (input)

features = [
"solar_irradiance",
"wind_speed",
"temperature",
"humidity",
"hour_of_day",
"day_of_week"
]

X = df[features]

# Targets

y_supply = df["total_renewable_energy"]
y_demand = df["grid_load_demand"]

# Time-based split (80-20)

split = int(len(df) * 0.8)

X_train = X[:split]
X_test = X[split:]

y_sup_train = y_supply[:split]
y_sup_test = y_supply[split:]

y_dem_train = y_demand[:split]
y_dem_test = y_demand[split:]


# Train models

model_supply = RandomForestRegressor()
model_demand = RandomForestRegressor()

model_supply.fit(X_train, y_sup_train)
model_demand.fit(X_train, y_dem_train)

# Predictions

pred_supply = model_supply.predict(X_test)
pred_demand = model_demand.predict(X_test)

st.write("Length check:", len(pred_supply), len(pred_demand))



# ===============================

# 🔥 AI Optimization starts here

# ===============================

st.subheader("⚡ AI Optimization (Using ML Predictions)")

battery_capacity = st.slider("🔋 Battery Capacity", 50, 500, 100)

soc = 50

soc_pred = []
grid_pred = []

for i in range(len(pred_supply)):
  supply = pred_supply[i]
  demand = pred_demand[i]


for i in range(len(pred_supply)):
    supply = pred_supply[i]
    demand = pred_demand[i]

    if supply > demand:
        charge = min(supply - demand, battery_capacity - soc)
        soc += charge
        grid = -(supply - demand - charge)
    else:
        discharge = min(demand - supply, soc)
        soc -= discharge
        grid = demand - supply - discharge

    soc_pred.append(soc)
    grid_pred.append(grid)

st.write("Final lengths:", len(pred_supply), len(soc_pred), len(grid_pred))

print(len(pred_supply), len(pred_demand), len(soc_pred), len(grid_pred))

opt_df = pd.DataFrame({
    "Predicted Supply": pred_supply,
    "Predicted Demand": pred_demand,
    "Battery SOC": soc_pred,
    "Grid Exchange": grid_pred
})

# 💰 Cost Calculation

grid_cost = 10      # buying price
grid_sell = 5       # selling price

cost = 0

for g in grid_pred:
  if g > 0:
   cost += g * grid_cost
  else:
    cost += g * grid_sell

st.subheader("💰 Total Grid Cost")
st.write(f"Estimated Cost: ₹ {round(cost, 2)}")

st.subheader("📊 Supply vs Demand vs Grid")

plot_df = pd.DataFrame({
"Supply": pred_supply,
"Demand": pred_demand,
"Grid": grid_pred
})

st.line_chart(plot_df)




st.write(opt_df.head())

st.subheader("🔋 Optimized Battery SOC")
st.line_chart(opt_df["Battery SOC"])

st.subheader("🔌 Optimized Grid Exchange")
st.line_chart(opt_df["Grid Exchange"])


st.subheader("📊 Prediction Results")
pred_df = pd.DataFrame({
    "Actual Supply": y_sup_test.values,
    "Predicted Supply": pred_supply,
    "Actual Demand": y_dem_test.values,
    "Predicted Demand": pred_demand
})

st.write(pred_df.head())

col1, col2 = st.columns(2)

with col1:
   st.subheader("📊 Supply Prediction")
   st.line_chart(pred_df[["Actual Supply", "Predicted Supply"]])

with col2:
   st.subheader("📊 Demand Prediction")
   st.line_chart(pred_df[["Actual Demand", "Predicted Demand"]])


st.markdown("---")
st.subheader("⚡ Optimization Dashboard")

col3, col4 = st.columns(2)

with col3:
  st.subheader("🔋 Battery SOC")
  st.line_chart(opt_df["Battery SOC"])

with col4:
  st.subheader("🔌 Grid Exchange")
  st.line_chart(opt_df["Grid Exchange"])

st.markdown("---")
st.subheader("📊 Supply vs Demand vs Grid")

plot_df = pd.DataFrame({
"Supply": pred_supply,
"Demand": pred_demand,
"Grid": grid_pred
})

st.line_chart(plot_df)

st.markdown("---")
st.subheader("💰 Total Grid Cost")

st.success(f"Estimated Cost: ₹ {round(cost, 2)}")



